#!/bin/python

import sys

print("\n\nHello Python CGI !")
print("Python " + str(sys.version))
