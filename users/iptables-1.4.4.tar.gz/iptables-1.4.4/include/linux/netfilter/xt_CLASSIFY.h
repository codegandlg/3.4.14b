#ifndef _XT_CLASSIFY_H
#define _XT_CLASSIFY_H

struct xt_classify_target_info {
	u_int32_t priority;
};

#endif /*_XT_CLASSIFY_H */
