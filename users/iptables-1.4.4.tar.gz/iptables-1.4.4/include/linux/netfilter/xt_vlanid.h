#ifndef _XT_VLANID_H
#define _XT_VLANID_H

struct xt_vlanid_info {
    u_int16_t vid;
    u_int8_t invert;
};

#endif /*_XT_VLANID_H*/
