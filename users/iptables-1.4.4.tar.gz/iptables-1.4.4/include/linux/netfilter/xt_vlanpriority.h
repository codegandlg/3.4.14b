#ifndef _XT_VLANPRIORITY_H
#define _XT_VLANPRIORITY_H

struct xt_vlanpriority_info {
    u_int8_t priority;
    u_int8_t invert;
};

#endif /*_XT_MARK_H*/

